import { Component } from '@angular/core';

@Component({
  selector: 'app-my-book-page',
  templateUrl: './my-book-page.component.html',
  styleUrls: ['./my-book-page.component.scss']
})
export class MyBookPageComponent {

}
